# Creative Commons Attribution 4.0 International

Copyright © 2026 Edikka / Bertrand Morel.

The original Edikka-authored material in this package is licensed under the
Creative Commons Attribution 4.0 International licence (CC BY 4.0).

You are free to share and adapt that material for any purpose, including
commercial use, provided that you give appropriate credit, provide a link to
the licence and indicate whether changes were made.

Licence summary and legal code:
https://creativecommons.org/licenses/by/4.0/

## Scope

This grant covers the Edikka-authored fixtures, `expected.json`, result
summaries, observations and documentation stored in this v1.2 package.

It does not relicense third-party software, dependency notices, third-party
web pages or extracts, trademarks, the Edikka website as a whole, or material
for which Edikka does not hold the necessary rights. Those items remain under
their respective terms. The archived real-page inputs are supplied as research
evidence; this licence applies only to original Edikka-authored content within
them and not to third-party components that may be present.

Suggested attribution:

> Edikka / Bertrand Morel, “Semantic HTML extraction protocol v1.2.0”, 2026,
> licensed under CC BY 4.0.
