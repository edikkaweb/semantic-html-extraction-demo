# Paquet HTML sémantique 1.2.1 — protocole d’extraction 1.2.0

## Correction de l’évaluation — 21 septembre 2026

Le protocole d’extraction reste en v1.2.0 ; le schéma d’évaluation passe à 2 (révision 2.0.0). Aucun extracteur n’a été relancé pour cette correction. Les octets, dates, témoins de répétition et résultat défavorable de newspaper4k sont conservés. [results-original-v1.2.0.json](results-original-v1.2.0.json) archive le premier agrégat. Ses évaluations et celles incluses dans les sorties brutes sont historiques ; les verdicts révisés figurent dans [results.json](results.json).

Chaque cas expose les sept outils. Les relations d’en-tête de ligne et de colonne sont distinctes ; intitulés et valeurs exacts doivent être présents dans le même tableau. Une légende XML marquée role=head ne vaut pas en-tête de colonne. Trafilatura conserve les colonnes de la variante th uniquement, sans relation explicite de ligne. Une ligne d’en-têtes Markdown est signalée séparément de la sémantique HTML source. Avec html2text, la légende rejoint le premier intitulé : l’association exacte n’est pas validée. no_output signifie absence de sortie, donc relation non évaluée. Les verdicts comprennent le champ brut, son SHA-256 et un extrait.

La présence de la réserve est évaluée ; son rattachement à l’affirmation est **non évalué**. Le niveau de titre est observé, sans preuve indépendante d’appartenance à une section.

Les quatre anciens contre-tests étaient des déclarations fixes. Le script exécute désormais quatre altérations dans chaque langue : valeur changée, réserve retirée, valeurs permutées et texte concordant hors tableau. Un témoin valide est d’abord accepté. Les huit verdicts, empreintes et extraits figurent dans evaluator_counter_tests. Ce sont des tests de l’évaluateur sur les sorties archivées, pas de nouvelles exécutions d’extracteurs.

Après installation des dépendances Node figées de reproduce/, recalculer l’agrégat depuis les sorties archivées :

```sh
node reproduce/refresh-relations.mjs "$PWD"
```


## Licence

Les contenus originaux créés par Edikka dans ce paquet sont placés sous
[CC BY 4.0](LICENSE.md). Les logiciels tiers, leurs notices et les contenus
sur lesquels Edikka ne détient pas les droits conservent leurs propres termes.

Cette relance additive conserve intactes les versions v1.0 et v1.1. Les mêmes 12 fixtures FR/EN contrôlées sont traitées par sept outils : Mozilla Readability 0.6.0, Trafilatura 2.2.0, readability-lxml 0.8.4.1, newspaper4k 0.9.3.1, jusText 3.0.2, html2text 2025.4.15 et markdownify 1.2.2.

Les cinq premiers sont des extracteurs ou outils de lecture aux modèles de sortie différents. Les deux derniers convertissent le HTML en Markdown sans sélectionner le contenu de la même manière. Ils ne forment donc pas un classement unique. `expected.json` décrit séparément les informations et relations évaluées.

Chaque outil est réellement exécuté deux fois sur les mêmes octets. Ces cas synthétiques mesurent conservation, aplatissement ou suppression—notamment pas conformité d’accessibilité, indexation, classement, sélection, compréhension d’un modèle ou citation.

## Entrée réellement fournie aux outils

Le runner ne supprime pas les balises de métadonnées et ne réécrit pas les fixtures avant extraction. Le fichier HTML archivé dans `fixtures/` est transmis tel quel à chaque adaptateur. Pour Mozilla Readability, JSDOM est configuré avec `runScripts: "outside-only"` et sans chargeur de ressources : les scripts présents ne sont pas exécutés et les ressources distantes ne sont pas récupérées. Empêcher une exécution ou un chargement n’est pas supprimer l’information du document.

Chaque sortie brute contient l’empreinte du fichier d’entrée, le témoin DOM vu avant extraction, la configuration et la sortie native de l’outil. Cette séparation permet de distinguer une perte due à l’extracteur d’une transformation préalable — inexistante dans cette version.

## Reproduction hors du dépôt

Le dossier `reproduce/` constitue le paquet autonome : runner, adaptateurs Python, exigences figées, `package.json`, lockfile et procédure. Copiez ce seul dossier ailleurs, exécutez `npm ci`, créez l’environnement Python puis lancez la commande indiquée dans `reproduce/README.md`. Le rejeu écrit ses fixtures et résultats dans la copie grâce à `SEMANTIC_OUTPUT_ROOT`.

`agent-interaction-results.json` est une preuve séparée : une interaction clavier réelle dans Chrome sur une fixture locale. Elle archive le HTML source, le DOM avant/après JavaScript et les nœuds d’accessibilité avant/après. Elle ne fait pas partie des douze documents d’extraction et ne constitue pas un benchmark d’agent autonome.

## Addendum sur pages réelles

`real-pages/` contient huit instantanés complets de pages de production Edikka archivés le 11 septembre 2026 : deux articles, le contact et la bibliothèque en FR/EN. Les sept outils sont exécutés deux fois sur chaque fichier, sans script exécuté ni ressource distante chargée. Cet échantillon de convenance sert uniquement à vérifier que le programme fonctionne hors des fixtures synthétiques ; il n’est ni représentatif du Web, ni causal, ni un classement des outils.

Le runner a révélé une instabilité de newspaper4k sur `article-ai-en` lors du rejeu conservé. Le résultat défavorable et les deux sorties sont archivés. L’adaptateur détermine désormais la langue à partir de `html[lang]`, et non plus du nom du fichier.
