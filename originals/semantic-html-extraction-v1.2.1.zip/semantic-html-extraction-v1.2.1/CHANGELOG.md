# Package 1.2.1 — 21 September 2026

Extraction protocol: 1.2.0. Evaluation revision: 2.0.0. This release re-evaluates archived outputs; it adds no extractor observations.

- Separates row and column header relationships for all seven tools, with exact output excerpts, source fields and SHA-256.
- Corrects the false positive that counted an XML caption as column headers.
- Distinguishes Markdown layout from native source semantics and missing output from an evaluated negative result.
- Narrows caveat claims to presence; attachment to a claim is not evaluated.
- Replaces four fixed counter-test declarations with eight executed mutations (four per language), each with an accepted positive control.
- Retains the original aggregate, all raw inputs/outputs, original execution dates and unfavorable repeatability witness.

The previous public ZIP remains unchanged at `/docbd/data/semantic-html-extraction-v1.2.zip`.
SHA-256: `83cd3aaed52f51ca903b9cfa4ad1ee3f9e43763b57bd44e57c94845c26b3700b`.

## Français

Ce paquet distingue les relations d’en-tête de ligne et de colonne, corrige le faux positif lié à une légende XML et exécute réellement les quatre contre-tests dans chacune des deux langues. Les observations d’extraction initiales et leurs limites sont inchangées. Les anciens verdicts restent archivés dans `results-original-v1.2.0.json` et dans les fichiers bruts ; le résumé révisé `results.json` fait autorité pour l’évaluation 2.0.0. L’archive publique précédente reste intacte.
