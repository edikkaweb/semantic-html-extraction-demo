import {JSDOM} from 'jsdom';
import {evaluateRelations} from './evaluate-relations.mjs';

// These mutations test the evaluator on archived output, not an extractor.
export function runEvaluatorCounterTests(records) {
  const results = [];
  for (const language of ['fr', 'en']) {
    for (const id of ['changed-value', 'missing-caveat', 'swapped-table-values', 'misleading-occurrence']) {
      const family = id === 'missing-caveat' ? 'caveat' : 'table';
      const original = records.find(record => record.id === `${family}-${language}-1`);
      if (!original) throw new Error(`Missing positive control: ${family}-${language}-1`);
      const accepts = result => family === 'caveat' ? result.caveat_text === 'present'
        : result.expected_data_row === 'exact_values_in_order' && result.column_header_relation === 'explicit';
      if (!accepts(evaluateRelations(original).relation.readability)) throw new Error('Positive control failed');
      const altered = structuredClone(original);
      const document = new JSDOM(altered.readability.content).window.document;
      if (family === 'table') {
        const table = document.querySelector('table');
        const cells = table.querySelector('tbody tr').children;
        if (id === 'changed-value') cells[3].textContent = '9.9';
        if (id === 'swapped-table-values') {
          const value = cells[1].innerHTML;
          cells[1].innerHTML = cells[2].innerHTML;
          cells[2].innerHTML = value;
        }
        if (id === 'misleading-occurrence') {
          const paragraph = document.createElement('p');
          paragraph.textContent = table.textContent;
          table.replaceWith(paragraph);
        }
      } else {
        const prefix = language === 'fr' ? 'Réserve essentielle :' : 'Essential caveat:';
        const caveat = [...document.querySelectorAll('p')].find(node => node.textContent.includes(prefix));
        if (!caveat) throw new Error('Caveat mutation target missing');
        caveat.remove();
      }
      altered.readability.content = document.body.innerHTML;
      if (altered.readability.content === original.readability.content) throw new Error('Mutation had no effect');
      const verdict = evaluateRelations(altered).relation.readability;
      const accepted = accepts(verdict);
      results.push({id, language, positive_control: original.id, positive_control_accepted: true,
        evaluated_tool_output: 'readability.content', accepted, passed: !accepted, verdict});
    }
  }
  if (results.some(result => !result.passed)) throw new Error('An evaluator counter-test accepted a corrupted output');
  return results;
}
