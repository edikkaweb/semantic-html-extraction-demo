#!/usr/bin/env python3
"""Offline Trafilatura adapter for the semantic HTML extraction protocol."""

from __future__ import annotations

import json
import pathlib
import sys

import trafilatura


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("usage: extract_trafilatura.py INPUT.html")

    source = pathlib.Path(sys.argv[1])
    html = source.read_text(encoding="utf-8")
    common = {
        "include_comments": False,
        "include_links": True,
        "include_tables": True,
        "no_fallback": False,
        "favor_precision": False,
        "favor_recall": False,
    }
    xml = trafilatura.extract(html, output_format="xml", **common)
    text = trafilatura.extract(html, output_format="txt", **common)
    payload = {
        "tool": "trafilatura",
        "version": getattr(trafilatura, "__version__", "unknown"),
        "configuration": {**common, "formats": ["xml", "txt"]},
        "source": source.name,
        "xml": xml,
        "text": text,
        "status": "ok" if xml is not None or text is not None else "no_output",
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
