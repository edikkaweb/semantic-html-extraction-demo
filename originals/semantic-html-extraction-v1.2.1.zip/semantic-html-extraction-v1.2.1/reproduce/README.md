# Standalone reproduction bundle

This directory contains the runner, pinned Node lockfile and pinned Python requirements needed to recreate the v1.2 fixtures and outputs outside the Edikka repository.

Original Edikka-authored material in this bundle is licensed under [CC BY 4.0](LICENSE.md). Third-party dependencies retain their own terms.

```sh
cp -R reproduce /tmp/semantic-html-v1-2
cd /tmp/semantic-html-v1-2
npm ci --ignore-scripts
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-v1.2.txt
SEMANTIC_PROTOCOL_VERSION=1.2.0 \
SEMANTIC_OUTPUT_ROOT="$PWD" \
TRAFILATURA_PYTHON="$PWD/.venv/bin/python" \
MULTITOOL_PYTHON="$PWD/.venv/bin/python" \
node run.mjs
```

The run rewrites `fixtures/`, `outputs/`, `results.json` and `manifest.json` in the copied directory. Network access is needed only to install dependencies that are not already cached. The experiment uses synthetic data and does not contact a search engine or AI service.

The included first-party real-page sample can then be replayed separately:

```sh
REAL_PAGE_INPUT_ROOT="$PWD/real-pages/inputs" \
REAL_PAGE_OUTPUT_ROOT="$PWD/real-pages" \
TRAFILATURA_PYTHON="$PWD/.venv/bin/python" \
MULTITOOL_PYTHON="$PWD/.venv/bin/python" \
node audit-real-pages.mjs
```

That bounded convenience sample is descriptive, not representative or causal.
