import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {evaluateRelations} from './evaluate-relations.mjs';
import {runEvaluatorCounterTests} from './counter-tests.mjs';

const root = process.argv[2] || fileURLToPath(new URL('../../docbd/data/semantic-html-extraction-v1.2.1/', import.meta.url));
const resultsPath = path.join(root, 'results.json');
const originalPath = path.join(root, 'results-original-v1.2.0.json');
if (!fs.existsSync(originalPath)) fs.copyFileSync(resultsPath, originalPath, fs.constants.COPYFILE_EXCL);
const bytes = fs.readFileSync(originalPath);
const results = JSON.parse(bytes);
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const inputs = [];
const records = [];
for (const item of results.cases) {
  const rawBytes = fs.readFileSync(path.join(root, item.raw_output));
  const raw = JSON.parse(rawBytes);
  if (raw.id !== item.id || raw.html_sha256 !== item.html_sha256 || hash(fs.readFileSync(path.join(root, item.fixture))) !== item.html_sha256) throw new Error('Archived fixture/output mismatch: ' + item.id);
  item.evaluation = evaluateRelations(raw);
  records.push(raw);
  inputs.push({path: item.raw_output, sha256: hash(rawBytes)});
}
results.evaluator_counter_tests = runEvaluatorCounterTests(records);
results.evaluation_revision = {
  version: '2.0.0', reviewed_on: '2026-09-21', extraction_rerun: false, counter_tests_executed: true,
  counter_test_correction: 'The original four accepted:false entries were declarations, not executed checks. This revision executes four mutations per language against archived outputs, each with a positive control.',
  original_aggregate: {path: path.basename(originalPath), sha256: hash(bytes)}, raw_outputs: inputs,
  note: 'Only evaluation of archived outputs was refined. Original extraction dates, outputs and repeatability results are unchanged. Raw-file evaluation fields are the legacy v1 summary; this aggregate supersedes them.',
};
fs.writeFileSync(resultsPath, JSON.stringify(results, null, 2) + '\n');
console.log('Re-evaluated 12 archived cases across seven tools; no extraction rerun.');
