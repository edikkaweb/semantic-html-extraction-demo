import crypto from 'node:crypto';
import {JSDOM} from 'jsdom';

const expectations = {
  fr: {heading: 'Conditions de mesure', columns: ['Indicateur', 'Unité', 'Période', 'Valeur'], row: ['Temps de réponse', 'secondes', 'mai 2026', '1,8'], caveat: 'Réserve essentielle : cet exemple synthétique ne mesure ni un trafic réel, ni un classement, ni une citation par un système d’IA.'},
  en: {heading: 'Measurement conditions', columns: ['Indicator', 'Unit', 'Period', 'Value'], row: ['Response time', 'seconds', 'May 2026', '1.8'], caveat: 'Essential caveat: this synthetic example measures neither real traffic, ranking, nor citation by an AI system.'},
};
const normal = text => text.replace(/\s+/gu, ' ').trim();
const same = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
const hash = text => crypto.createHash('sha256').update(text).digest('hex');

function structured(output, format, expected, family) {
  const document = new JSDOM(output, format === 'xml' ? {contentType: 'text/xml'} : {}).window.document;
  const text = normal(document.documentElement.textContent);
  if (family === 'table') {
    const tables = [...document.querySelectorAll('table')];
    const table = tables.find(t => normal(t.textContent).includes(expected.row[0]));
    const rows = table ? [...table.querySelectorAll(format === 'xml' ? 'row' : 'tr')].map(row => [...row.children]) : [];
    const labels = row => row.map(cell => normal(cell.textContent));
    const header = rows.find(row => same(labels(row), expected.columns));
    const data = rows.find(row => same(labels(row), expected.row));
    const columnExplicit = header?.every(cell => format === 'xml'
      ? cell.getAttribute('role') === 'head'
      : cell.matches('th[scope="col"], [role="columnheader"]')) || false;
    const rowExplicit = Boolean(data?.[0] && (format === 'xml'
      ? data[0].getAttribute('role') === 'head'
      : data[0].matches('th[scope="row"], [role="rowheader"]')));
    return {
      table_structure: table ? 'present' : 'absent',
      expected_data_row: data ? 'exact_values_in_order' : 'not_found',
      column_header_relation: columnExplicit && data ? 'explicit' : 'not_explicit',
      row_header_relation: rowExplicit ? 'explicit' : 'not_explicit',
      column_labels: header ? labels(header) : [],
      data_values: data ? labels(data) : [],
      // Excludes the caption: role=head on a caption is not a column relationship.
      evidence: {header_row: header?.map(cell => cell.outerHTML).join('') || null, data_row: data?.map(cell => cell.outerHTML).join('') || null, table_excerpt: table?.outerHTML || null},
    };
  }
  if (family === 'heading') {
    const heading = [...document.querySelectorAll(format === 'xml' ? 'head[rend]' : 'h1,h2,h3,h4,h5,h6')].find(node => normal(node.textContent) === expected.heading);
    return {heading_relation: heading ? 'explicit' : text.includes(expected.heading) ? 'text_only' : 'absent', heading_level: heading ? (format === 'xml' ? heading.getAttribute('rend') : heading.tagName.toLowerCase()) : null, evidence: {excerpt: heading?.outerHTML || (text.includes(expected.heading) ? expected.heading : null)}};
  }
  const present = text.includes(expected.caveat);
  const aside = [...document.querySelectorAll('aside')].find(node => normal(node.textContent).includes(expected.caveat));
  return {caveat_text: present ? 'present' : 'absent', caveat_element: aside ? 'aside' : present ? 'not_aside' : 'absent', attachment_to_claim: 'not_evaluated', evidence: {excerpt: present ? expected.caveat : null}};
}

function unstructured(output, format, expected, family) {
  if (family === 'table') {
    const lines = output.split('\n').filter(line => line.includes('|'));
    const cells = line => line.trim().replace(/^\||\|$/g, '').split('|').map(normal);
    const headerIndex = lines.findIndex(line => same(cells(line), expected.columns));
    const header = headerIndex >= 0 && /^\s*\|?[\s:|\-]+\|?\s*$/.test(lines[headerIndex + 1] || '');
    const data = lines.find(line => same(cells(line), expected.row));
    return {
      table_structure: format === 'markdown' && lines.length ? 'markdown_layout' : 'absent',
      expected_data_row: data ? 'exact_values_in_order' : 'not_found',
      column_header_relation: header && data ? 'markdown_header_row' : 'not_explicit',
      row_header_relation: format === 'markdown' ? 'not_encoded_in_markdown' : 'not_explicit',
      column_labels: header ? expected.columns : [], data_values: data ? expected.row : [],
      evidence: {header_row: header ? lines[headerIndex] + '\n' + lines[headerIndex + 1] : null, data_row: data || null, table_excerpt: lines.length ? lines.join('\n') : output.slice(0, 1600)},
    };
  }
  if (family === 'heading') {
    const line = output.split('\n').find(line => /^#{1,6}\s/.test(line) && normal(line.replace(/^#+\s*/, '')) === expected.heading);
    return {heading_relation: line ? 'markdown_heading' : output.includes(expected.heading) ? 'text_only' : 'absent', heading_level: line ? 'h' + line.match(/^#+/)[0].length : null, evidence: {excerpt: line || (output.includes(expected.heading) ? expected.heading : null)}};
  }
  const present = normal(output).includes(expected.caveat);
  return {caveat_text: present ? 'present' : 'absent', caveat_element: 'not_encoded_in_text', attachment_to_claim: 'not_evaluated', evidence: {excerpt: present ? expected.caveat : null}};
}

export function evaluateRelations(record) {
  const expected = expectations[record.language];
  if (!expected) throw new Error('Unknown fixture language');
  const more = record.additional_extractors || {};
  const tools = {
    readability: [record.readability, 'content', 'html', 'content_extractor'],
    trafilatura: [record.trafilatura, 'xml', 'xml', 'content_extractor'],
    readability_lxml: [more.readability_lxml, 'html', 'html', 'content_extractor'],
    newspaper4k: [more.newspaper4k, 'html', 'html', 'content_extractor'],
    justext: [more.justext, 'text', 'text', 'content_extractor'],
    html2text: [more.html2text, 'markdown', 'markdown', 'markdown_converter'],
    markdownify: [more.markdownify, 'markdown', 'markdown', 'markdown_converter'],
  };
  const source = record.family === 'table'
    ? {row_header_relation: record.dom_witness.tables.some(t => t.cells.some(c => c.scope === 'row')) ? 'explicit' : 'not_explicit', column_header_relation: record.dom_witness.tables.some(t => t.cells.some(c => c.scope === 'col')) ? 'explicit' : 'not_explicit'}
    : {fixture_variant: record.variant};
  const relation = {source};
  for (const [name, [tool, field, format, toolClass]] of Object.entries(tools)) {
    if (!tool || tool.status !== 'ok' || !tool[field]) {
      relation[name] = {status: tool?.status || 'not_run', tool_class: toolClass, format, row_header_relation: 'not_evaluated', column_header_relation: 'not_evaluated', evidence: null};
      continue;
    }
    const output = tool[field];
    const result = ['html', 'xml'].includes(format) ? structured(output, format, expected, record.family) : unstructured(output, format, expected, record.family);
    relation[name] = {status: 'ok', tool_class: toolClass, format, ...result, output_field: name === 'readability' || name === 'trafilatura' ? `${name}.${field}` : `additional_extractors.${name}.${field}`, output_sha256: hash(output)};
    if (record.family === 'table') relation[name].source_column_headers_explicit = source.column_header_relation === 'explicit';
  }
  return {schema_version: 2, method: 'Exact expected labels and values in the same table; captions excluded from column-header detection. Markdown layout is reported separately from native HTML semantics. No claim-attachment inference.', relation};
}
