#!/usr/bin/env node

import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';
import { Readability } from '@mozilla/readability';
import { evaluateRelations } from './evaluate-relations.mjs';
import { runEvaluatorCounterTests } from './counter-tests.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');
const protocolVersion = process.env.SEMANTIC_PROTOCOL_VERSION || '1.2.0';
const outputDirectory = process.env.SEMANTIC_OUTPUT_DIRECTORY || 'semantic-html-replay-1.2.1';
const outputRoot = process.env.SEMANTIC_OUTPUT_ROOT
  ? path.resolve(process.env.SEMANTIC_OUTPUT_ROOT)
  : path.join(os.tmpdir(), outputDirectory);
if (outputRoot.startsWith(path.join(root, 'docbd/data/semantic-html-extraction-'))) throw new Error('Replay output must be outside published extraction archives.');
const fixturesRoot = path.join(outputRoot, 'fixtures');
const rawRoot = path.join(outputRoot, 'outputs');
const python = process.env.TRAFILATURA_PYTHON || 'python3';
const multitoolPython = process.env.MULTITOOL_PYTHON || null;
const executedAt = new Date().toISOString();

const copy = {
  fr: {
    title: 'Protocole hors ligne de conservation des relations',
    lead: 'Ce document synthétique sert à comparer deux balisages à texte, ordre, classes et environnement identiques. Les données sont fictives et ne décrivent ni Edikka ni un client.',
    heading: 'Conditions de mesure',
    headingBody: 'Le capteur A a fonctionné pendant 30 minutes. La mesure a été répétée dans le même environnement, sans ressource distante ni script exécuté.',
    tableTitle: 'Mesures synthétiques',
    metric: 'Indicateur', unit: 'Unité', period: 'Période', value: 'Valeur',
    speed: 'Temps de réponse', seconds: 'secondes', may: 'mai 2026', number: '1,8',
    claims: 'Résultat synthétique',
    claim: 'Le taux observé est de 42 % sur 200 opérations simulées en mai 2026.',
    reserve: 'Réserve essentielle : cet exemple synthétique ne mesure ni un trafic réel, ni un classement, ni une citation par un système d’IA.',
    close: 'La conclusion doit être relue avec son unité, sa période, son périmètre et sa réserve. La présence d’un mot dans une sortie ne suffit pas à prouver que la relation a été conservée.'
  },
  en: {
    title: 'Offline protocol for preserving relationships',
    lead: 'This synthetic document compares two markups while text, order, classes and surroundings remain identical. The data are fictional and describe neither Edikka nor a client.',
    heading: 'Measurement conditions',
    headingBody: 'Sensor A operated for 30 minutes. The measurement was repeated in the same environment, without remote resources or executed scripts.',
    tableTitle: 'Synthetic measurements',
    metric: 'Indicator', unit: 'Unit', period: 'Period', value: 'Value',
    speed: 'Response time', seconds: 'seconds', may: 'May 2026', number: '1.8',
    claims: 'Synthetic result',
    claim: 'The observed rate is 42% across 200 simulated operations in May 2026.',
    reserve: 'Essential caveat: this synthetic example measures neither real traffic, ranking, nor citation by an AI system.',
    close: 'The conclusion must be read with its unit, period, scope and caveat. Finding a word in an output is not enough to prove that the relationship was preserved.'
  }
};

const families = {
  heading: [
    { variant: 'heading-element', open: '<h2 class="case-marker">', close: '</h2>' },
    { variant: 'generic-element', open: '<div class="case-marker">', close: '</div>' }
  ],
  table: [
    { variant: 'header-cells', colOpen: '<th class="case-cell" scope="col">', colClose: '</th>', rowOpen: '<th class="case-cell" scope="row">', rowClose: '</th>' },
    { variant: 'data-cells', colOpen: '<td class="case-cell">', colClose: '</td>', rowOpen: '<td class="case-cell">', rowClose: '</td>' }
  ],
  caveat: [
    { variant: 'paragraph-element', open: '<p class="case-caveat">', close: '</p>' },
    { variant: 'aside-element', open: '<aside class="case-caveat">', close: '</aside>' }
  ]
};

function escapeHtml(value) {
  return value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}

function fixtureHtml(language, family, variant) {
  const c = copy[language];
  let treatment;
  if (family === 'heading') {
    treatment = `${variant.open}${c.heading}${variant.close}<p>${c.headingBody}</p>`;
  } else if (family === 'table') {
    const cell = (text, row = false) => `${row ? variant.rowOpen : variant.colOpen}${text}${row ? variant.rowClose : variant.colClose}`;
    treatment = `<h2>${c.tableTitle}</h2><table><caption>${c.tableTitle}</caption><thead><tr>${cell(c.metric)}${cell(c.unit)}${cell(c.period)}${cell(c.value)}</tr></thead><tbody><tr>${cell(c.speed, true)}<td class="case-cell">${c.seconds}</td><td class="case-cell">${c.may}</td><td class="case-cell">${c.number}</td></tr></tbody></table>`;
  } else {
    treatment = `<h2>${c.claims}</h2><p>${c.claim}</p>${variant.open}${c.reserve}${variant.close}`;
  }
  return `<!doctype html>
<html lang="${language}"><head><meta charset="utf-8"><title>${c.title}</title><style>.case-marker{font-size:1.5rem;font-weight:700}.case-cell{padding:.4rem;border:1px solid #777}.case-caveat{padding:.75rem;border-left:4px solid #555}table{border-collapse:collapse}</style></head>
<body><header><p>Edikka · semantic HTML extraction protocol · v${protocolVersion}</p></header><main><article><h1>${c.title}</h1><p>${c.lead}</p>${treatment}<p>${c.close}</p></article></main><footer><p>Offline synthetic fixture · v${protocolVersion}</p></footer></body></html>`;
}

function normalizedVisibleText(html) {
  const dom = new JSDOM(html, { runScripts: 'outside-only', resources: undefined });
  for (const node of dom.window.document.querySelectorAll('script,style,noscript,template')) node.remove();
  return dom.window.document.body.textContent.replace(/\s+/gu, ' ').trim();
}

function maskTreatmentMarkup(html, family) {
  if (family === 'heading') {
    return html
      .replace(/<(?:h2|div) class="case-marker">/u, '<TREATMENT>')
      .replace(/<\/(?:h2|div)><p>/u, '</TREATMENT><p>');
  }
  if (family === 'table') {
    return html
      .replace(/<(?:th class="case-cell" scope="(?:col|row)"|td class="case-cell")>/gu, '<CELL>')
      .replace(/<\/(?:th|td)>/gu, '</CELL>');
  }
  return html
    .replace(/<(?:p|aside) class="case-caveat">/u, '<TREATMENT>')
    .replace(/<\/(?:p|aside)>(?=<p>)/u, '</TREATMENT>');
}

function domWitness(html) {
  const dom = new JSDOM(html, { runScripts: 'outside-only', resources: undefined });
  const document = dom.window.document;
  return {
    headings: [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].map(node => ({ level: Number(node.tagName.slice(1)), text: node.textContent.trim() })),
    tables: [...document.querySelectorAll('table')].map(table => ({
      caption: table.querySelector('caption')?.textContent.trim() || null,
      cells: [...table.querySelectorAll('th,td')].map(node => ({ element: node.tagName.toLowerCase(), scope: node.getAttribute('scope'), text: node.textContent.trim() }))
    })),
    asides: [...document.querySelectorAll('aside')].map(node => node.textContent.trim()),
    paragraphs: [...document.querySelectorAll('p')].map(node => node.textContent.trim())
  };
}

function hash(value) { return crypto.createHash('sha256').update(value).digest('hex'); }

function readabilityResult(html, filename) {
  const dom = new JSDOM(html, { url: `https://fixtures.invalid/${filename}`, runScripts: 'outside-only', resources: undefined });
  const parsed = new Readability(dom.window.document.cloneNode(true), { keepClasses: false }).parse();
  return {
    tool: '@mozilla/readability', version: '0.6.0',
    configuration: { keepClasses: false, charThreshold: 500, disableJSONLD: false },
    status: parsed ? 'ok' : 'no_output',
    title: parsed?.title ?? null, byline: parsed?.byline ?? null,
    dir: parsed?.dir ?? null, lang: parsed?.lang ?? null,
    siteName: parsed?.siteName ?? null, publishedTime: parsed?.publishedTime ?? null,
    excerpt: parsed?.excerpt ?? null, content: parsed?.content ?? null,
    textContent: parsed?.textContent ?? null, length: parsed?.length ?? 0,
  };
}

function evaluate(record) {
  return evaluateRelations(record);
}

fs.mkdirSync(fixturesRoot, { recursive: true });
fs.mkdirSync(rawRoot, { recursive: true });

const cases = [];
const replayChecks = [];
for (const language of ['fr', 'en']) {
  for (const [family, variants] of Object.entries(families)) {
    const pair = variants.map((variant, index) => {
      const id = `${family}-${language}-${index + 1}`;
      const filename = `${id}.html`;
      const html = fixtureHtml(language, family, variant);
      fs.writeFileSync(path.join(fixturesRoot, filename), html + '\n');
      return { id, language, family, pair_id: `${family}-${language}`, variant: variant.variant, filename, html };
    });
    const texts = pair.map(item => normalizedVisibleText(item.html));
    if (texts[0] !== texts[1]) throw new Error(`Visible text mismatch in ${family}-${language}`);
    const maskedMarkup = pair.map(item => maskTreatmentMarkup(item.html, family));
    if (maskedMarkup[0] !== maskedMarkup[1]) throw new Error(`Unexpected markup delta in ${family}-${language}`);
    for (const item of pair) {
      const readability = readabilityResult(item.html, item.filename);
      const trafilatura = JSON.parse(execFileSync(python, [path.join(here, 'extract_trafilatura.py'), path.join(fixturesRoot, item.filename)], { encoding: 'utf8' }));
      const additionalExtractors = multitoolPython
        ? JSON.parse(execFileSync(multitoolPython, [path.join(here, 'extract_multitool.py'), path.join(fixturesRoot, item.filename)], { encoding: 'utf8' }))
        : null;
      const record = {
        protocol_version: protocolVersion, executed_at: executedAt,
        id: item.id, pair_id: item.pair_id, family: item.family, language: item.language, variant: item.variant,
        synthetic_data: true, html_sha256: hash(item.html + '\n'), visible_text_sha256: hash(texts[0]),
        visible_text_equality_with_pair: true, pair_markup_equal_after_masking_treatment: true,
        dom_witness: domWitness(item.html), readability, trafilatura,
        additional_extractors: additionalExtractors
      };
      record.evaluation = evaluate(record);
      fs.writeFileSync(path.join(rawRoot, `${item.id}.json`), JSON.stringify(record, null, 2) + '\n');
      cases.push(record);
      const replay = {
        readability: readabilityResult(item.html, item.filename),
        trafilatura: JSON.parse(execFileSync(python, [path.join(here, 'extract_trafilatura.py'), path.join(fixturesRoot, item.filename)], { encoding: 'utf8' })),
        additional_extractors: multitoolPython
          ? JSON.parse(execFileSync(multitoolPython, [path.join(here, 'extract_multitool.py'), path.join(fixturesRoot, item.filename)], { encoding: 'utf8' }))
          : null
      };
      replayChecks.push({
        id: item.id,
        first_sha256: hash(JSON.stringify({ readability, trafilatura, additional_extractors: additionalExtractors })),
        replay_sha256: hash(JSON.stringify(replay))
      });
    }
  }
}

// Each extractor is executed a second time on the same bytes; hashes exclude only run metadata.
const determinism = replayChecks.every(check => check.first_sha256 === check.replay_sha256);

// Evaluator counter-tests: these are evaluator tests, not extractor observations.
const evaluatorCounterTests = runEvaluatorCounterTests(cases);

const results = {
  protocol_version: protocolVersion, executed_at: executedAt,
  environment: { platform: process.platform, architecture: process.arch, node: process.version, python, multitool_python: multitoolPython, hostname_redacted: true },
  tool_versions: {
    '@mozilla/readability': '0.6.0',
    trafilatura: cases[0]?.trafilatura?.version ?? null,
    ...(cases[0]?.additional_extractors ? Object.fromEntries(Object.entries(cases[0].additional_extractors).filter(([key]) => key !== 'source').map(([key, value]) => [key, value.version])) : {})
  },
  scope: { documents: cases.length, families: 3, languages: 2, variants_per_pair: 2, independent_web_sample: false },
  options_note: 'The received fixture bytes were passed unchanged to the extractors. JSDOM did not execute scripts or fetch external resources; metadata elements were not removed.',
  determinism_control: { passed: determinism, compared: 'second real execution of all seven tools on identical fixture bytes', cases: replayChecks },
  evaluator_counter_tests: evaluatorCounterTests,
  cases: cases.map(record => ({
    id: record.id, pair_id: record.pair_id, family: record.family, language: record.language, variant: record.variant,
    synthetic_data: record.synthetic_data, html_sha256: record.html_sha256, visible_text_sha256: record.visible_text_sha256,
    visible_text_equality_with_pair: record.visible_text_equality_with_pair,
    pair_markup_equal_after_masking_treatment: record.pair_markup_equal_after_masking_treatment,
    tools: {
      readability: record.readability.status,
      trafilatura: record.trafilatura.status,
      ...(record.additional_extractors ? Object.fromEntries(Object.entries(record.additional_extractors).filter(([key]) => key !== 'source').map(([key, value]) => [key, value.status])) : {})
    },
    evaluation: record.evaluation,
    raw_output: `outputs/${record.id}.json`, fixture: `fixtures/${record.id}.html`
  }))
};
fs.writeFileSync(path.join(outputRoot, 'results.json'), JSON.stringify(results, null, 2) + '\n');

const manifestFiles = [];
function nestedFiles(relativeDirectory) {
  const absoluteDirectory = path.join(outputRoot, relativeDirectory);
  if (!fs.existsSync(absoluteDirectory)) return [];
  return fs.readdirSync(absoluteDirectory, { withFileTypes: true }).flatMap(entry => {
    const relative = path.join(relativeDirectory, entry.name);
    return entry.isDirectory() ? nestedFiles(relative) : [relative];
  });
}

const manifestCandidates = [...new Set([
  'README.md', 'README-FR.md', 'LICENSE.md', 'OBSERVATIONS.md', 'expected.json', 'results.json', 'results-original-v1.2.0.json',
  'agent-interaction.html', 'agent-interaction-results.json',
  ...nestedFiles('real-pages'),
  ...nestedFiles('reproduce'),
  ...cases.flatMap(item => [`fixtures/${item.id}.html`, `outputs/${item.id}.json`]),
])];
for (const relative of manifestCandidates.filter(relative => fs.existsSync(path.join(outputRoot, relative)))) {
  const body = fs.readFileSync(path.join(outputRoot, relative));
  manifestFiles.push({ path: relative, bytes: body.length, sha256: hash(body) });
}
const manifest = { protocol_version: protocolVersion, generated_at: executedAt, files: manifestFiles };
fs.writeFileSync(path.join(outputRoot, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');

console.log(JSON.stringify({ status: 'ok', documents: cases.length, determinism, output: path.relative(root, outputRoot), tools: { readability: '0.6.0', trafilatura: cases[0]?.trafilatura.version } }, null, 2));
