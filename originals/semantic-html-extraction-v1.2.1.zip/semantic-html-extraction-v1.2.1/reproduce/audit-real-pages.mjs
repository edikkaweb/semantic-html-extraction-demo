#!/usr/bin/env node

import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';
import { Readability } from '@mozilla/readability';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');
const outputRoot = process.env.REAL_PAGE_OUTPUT_ROOT
  ? path.resolve(process.env.REAL_PAGE_OUTPUT_ROOT)
  : path.join(root, 'docbd/data/semantic-html-extraction-v1.2/real-pages');
const inputRoot = process.env.REAL_PAGE_INPUT_ROOT
  ? path.resolve(process.env.REAL_PAGE_INPUT_ROOT)
  : path.join(outputRoot, 'inputs');
const rawRoot = path.join(outputRoot, 'outputs');
const python = process.env.TRAFILATURA_PYTHON || 'python3';
const multitoolPython = process.env.MULTITOOL_PYTHON || python;

const archivedSources = [
  ['article-accessibility-fr', 'article', 'audit/bibliotheque-consolidation-2026-09-11/production-check/insights_developpement-web_accessibilite-web-bases-site-professionnel.html'],
  ['article-accessibility-en', 'article', 'audit/bibliotheque-consolidation-2026-09-11/production-check/en_insights_web-development_web-accessibility-professional-website-basics.html'],
  ['article-ai-fr', 'article', 'audit/bibliotheque-consolidation-2026-09-11/production-check/insights_ia-automatisation-web_ia-fiable-prompt-regles-metier.html'],
  ['article-ai-en', 'article', 'audit/bibliotheque-consolidation-2026-09-11/production-check/en_insights_ai-web-automation_reliable-ai-prompts-business-rules.html'],
  ['contact-fr', 'contact', 'audit/bibliotheque-consolidation-2026-09-11/production-check/contact.html'],
  ['contact-en', 'contact', 'audit/bibliotheque-consolidation-2026-09-11/production-check/en_contact.html'],
  ['library-fr', 'library', 'audit/bibliotheque-consolidation-2026-09-11/production-check/bibliotheque.html'],
  ['library-en', 'library', 'audit/bibliotheque-consolidation-2026-09-11/production-check/en_library.html'],
];

function hash(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function readability(html, url) {
  const dom = new JSDOM(html, { url, runScripts: 'outside-only', resources: undefined });
  const parsed = new Readability(dom.window.document.cloneNode(true), { keepClasses: false }).parse();
  return {
    tool: '@mozilla/readability', version: '0.6.0', status: parsed ? 'ok' : 'no_output',
    title: parsed?.title ?? null, byline: parsed?.byline ?? null, excerpt: parsed?.excerpt ?? null,
    content: parsed?.content ?? null, textContent: parsed?.textContent ?? null, length: parsed?.length ?? 0,
  };
}

fs.mkdirSync(inputRoot, { recursive: true });
fs.mkdirSync(rawRoot, { recursive: true });

let definitions;
if (process.env.REAL_PAGE_INPUT_ROOT) {
  definitions = fs.readdirSync(inputRoot)
    .filter(file => file.endsWith('.html'))
    .sort()
    .map(file => [path.basename(file, '.html'), file.includes('contact') ? 'contact' : file.includes('library') ? 'library' : 'article', null]);
} else {
  definitions = archivedSources;
  for (const [id, , relativeSource] of definitions) {
    fs.copyFileSync(path.join(root, relativeSource), path.join(inputRoot, `${id}.html`));
  }
}

const records = [];
for (const [id, pageType, relativeSource] of definitions) {
  const inputPath = path.join(inputRoot, `${id}.html`);
  const html = fs.readFileSync(inputPath, 'utf8');
  const dom = new JSDOM(html, { runScripts: 'outside-only', resources: undefined });
  const document = dom.window.document;
  const canonical = document.querySelector('link[rel="canonical"]')?.href || `https://snapshot.invalid/${id}`;
  const first = {
    readability: readability(html, canonical),
    trafilatura: JSON.parse(execFileSync(python, [path.join(here, 'extract_trafilatura.py'), inputPath], { encoding: 'utf8' })),
    additional_extractors: JSON.parse(execFileSync(multitoolPython, [path.join(here, 'extract_multitool.py'), inputPath], { encoding: 'utf8' })),
  };
  const replay = {
    readability: readability(html, canonical),
    trafilatura: JSON.parse(execFileSync(python, [path.join(here, 'extract_trafilatura.py'), inputPath], { encoding: 'utf8' })),
    additional_extractors: JSON.parse(execFileSync(multitoolPython, [path.join(here, 'extract_multitool.py'), inputPath], { encoding: 'utf8' })),
  };
  const firstHash = hash(JSON.stringify(first));
  const replayHash = hash(JSON.stringify(replay));
  const componentReplays = {
    readability: hash(JSON.stringify(first.readability)) === hash(JSON.stringify(replay.readability)),
    trafilatura: hash(JSON.stringify(first.trafilatura)) === hash(JSON.stringify(replay.trafilatura)),
    ...Object.fromEntries(Object.keys(first.additional_extractors)
      .filter(key => key !== 'source')
      .map(key => [key, hash(JSON.stringify(first.additional_extractors[key])) === hash(JSON.stringify(replay.additional_extractors[key]))])),
  };
  const nondeterministicOutputs = Object.fromEntries(Object.entries(componentReplays)
    .filter(([, stable]) => !stable)
    .map(([key]) => [key, key === 'readability' || key === 'trafilatura'
      ? { first: first[key], replay: replay[key] }
      : { first: first.additional_extractors[key], replay: replay.additional_extractors[key] }]));
  const record = {
    id,
    page_type: pageType,
    language: document.documentElement.lang || null,
    canonical,
    title: document.title,
    source_archive: relativeSource,
    source_html_sha256: hash(html),
    source_bytes: Buffer.byteLength(html),
    scripts_executed: false,
    external_resources_fetched: false,
    deterministic_replay: firstHash === replayHash,
    component_replays: componentReplays,
    nondeterministic_outputs: nondeterministicOutputs,
    first_output_sha256: firstHash,
    replay_output_sha256: replayHash,
    outputs: first,
  };
  fs.writeFileSync(path.join(rawRoot, `${id}.json`), JSON.stringify(record, null, 2) + '\n');
  records.push(record);
}

const summary = {
  protocol_version: '1.2.0-real-pages-addendum',
  executed_at: new Date().toISOString(),
  sampling: {
    method: 'bounded convenience sample of eight first-party Edikka production snapshots archived on 11 September 2026',
    page_types: ['article', 'contact', 'library'],
    languages: ['fr', 'en'],
    representative: false,
    causal_comparison: false,
    limitation: 'This addendum checks ecological execution only. It does not estimate extractor quality, web-wide prevalence, accessibility conformance, ranking or AI citation.',
  },
  preprocessing: 'Archived HTML bytes are passed unchanged. JSDOM does not execute scripts or fetch resources; metadata are not removed.',
  tools: ['@mozilla/readability 0.6.0', 'trafilatura 2.2.0', 'readability-lxml 0.8.4.1', 'newspaper4k 0.9.3.1', 'jusText 3.0.2', 'html2text 2025.4.15', 'markdownify 1.2.2'],
  pages: records.map(record => ({
    id: record.id, page_type: record.page_type, language: record.language, canonical: record.canonical,
    title: record.title, source_archive: record.source_archive, source_html_sha256: record.source_html_sha256,
    source_bytes: record.source_bytes, deterministic_replay: record.deterministic_replay,
    component_replays: record.component_replays,
    statuses: {
      readability: record.outputs.readability.status,
      trafilatura: record.outputs.trafilatura.status,
      ...Object.fromEntries(Object.entries(record.outputs.additional_extractors).filter(([key]) => key !== 'source').map(([key, value]) => [key, value.status])),
    },
    raw_output: `outputs/${record.id}.json`, input: `inputs/${record.id}.html`,
  })),
};
summary.all_deterministic = summary.pages.every(page => page.deterministic_replay);
fs.writeFileSync(path.join(outputRoot, 'results.json'), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify({ status: 'ok', pages: records.length, all_deterministic: summary.all_deterministic, output: path.relative(root, outputRoot) }, null, 2));
